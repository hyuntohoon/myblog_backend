# app/services/post_service.py
from __future__ import annotations

from datetime import date
from typing import Optional
import re

from sqlalchemy.orm import Session

from app.repositories.post_repository import PostRepository
from app.repositories.category_repository import CategoryRepository
from app.models.post import Post
from app.models.album import Album
from app.models.artist import Artist


def slugify_title(title: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (title or "").lower()).strip("-")
    return s or "untitled"


class PostService:
    """
    - 카테고리: 이름이 오면 get_or_create로 upsert (없으면 생성)
    - 슬러그: 중복 시 '-2', '-3' … 자동 suffix 부여로 유니크 보장
    """

    def __init__(self, post_repo: PostRepository, category_repo: CategoryRepository):
        self.post_repo = post_repo
        self.category_repo = category_repo

    def create(
        self,
        db: Session,
        *,
        title: str,
        description: str = "",
        body_mdx: str,
        posted_date: date,
        status: str = "published",
        category_name: Optional[str] = None,
        album_ids: Optional[list[str]] = None,
        artist_ids: Optional[list[str]] = None,
        # 🔥 새로 추가: 메인 커버 + 평점
        album_cover_url: Optional[str] = None,
        rating: Optional[float] = None,
    ) -> Post:
        album_ids = album_ids or []
        artist_ids = artist_ids or []

        # 1) 카테고리 처리 (없으면 default 사용)
        category_name = (category_name or "").strip() or "default"

        cat = self.category_repo.get_by_name(db, category_name)
        if not cat:
            cat = self.category_repo.create(db, category_name)
        category_id = cat.id

        # 2) 슬러그 유니크 보장
        base_slug = slugify_title(title)
        slug = self._ensure_unique_slug(db, base_slug)

        # 3) 포스트 생성 (+ album_cover_url, rating 전달)
        post = self.post_repo.create(
            db,
            slug=slug,
            title=title.strip(),
            description=description or "",
            body_mdx=body_mdx,
            posted_date=posted_date,
            status=status,
            category_id=category_id,
            album_cover_url=album_cover_url,  # 👈 새 필드
            rating=rating,                    # 👈 새 필드
        )

        # 4) 앨범 연결
        if album_ids:
            unique_ids = list({aid for aid in album_ids if aid})
            if unique_ids:
                albums = db.query(Album).filter(Album.id.in_(unique_ids)).all()
                for al in albums:
                    post.albums.append(al)

                db.commit()
                db.refresh(post)

        # 5) 아티스트 연결
        if artist_ids:
            unique_artist_ids = list({aid for aid in artist_ids if aid})
            if unique_artist_ids:
                artists = (
                    db.query(Artist)
                    .filter(Artist.id.in_(unique_artist_ids))
                    .all()
                )
                for ar in artists:
                    post.artists.append(ar)

        return post

    # ---------------------------
    # Internal Helpers
    # ---------------------------
    def _ensure_unique_slug(self, db: Session, base: str) -> str:
        """
        base가 이미 있으면 base-2, base-3 … 순차적으로 찾아 유니크 보장
        """
        if not self.post_repo.get_by_slug(db, base):
            return base

        i = 2
        while True:
            candidate = f"{base}-{i}"
            exists = self.post_repo.get_by_slug(db, candidate)
            if not exists:
                return candidate
            i += 1