# app/repositories/post_repository.py
from typing import List, Optional
from datetime import date

from sqlalchemy.orm import Session

from app.models.post import Post


class PostRepository:
    """posts 테이블 전용 리포지토리 (SQLAlchemy ORM 기반)."""

    def list_all(self, db: Session) -> List[Post]:
        """
        전체 포스트 목록을 posted_date DESC 로 반환
        """
        return (
            db.query(Post)
            .order_by(Post.posted_date.desc())
            .all()
        )

    def get_by_slug(self, db: Session, slug: str) -> Optional[Post]:
        """
        slug로 단일 포스트 조회
        """
        return (
            db.query(Post)
            .filter(Post.slug == slug)
            .first()
        )

    def create(
        self,
        db: Session,
        *,
        slug: str,
        title: str,
        description: str,
        body_mdx: str,
        posted_date: date,
        status: str,
        category_id: int,
        album_cover_url: Optional[str] = None,
        rating: float | None = None,
    ) -> Post:
        """
        새 Post 레코드를 생성하고 persistent 상태의 Post 인스턴스를 반환.
        (세션에 attach + commit + refresh 완료된 상태)
        """
        post = Post(
            slug=slug,
            title=title,
            description=description,
            body_mdx=body_mdx,
            posted_date=posted_date,
            status=status,
            category_id=category_id,
            album_cover_url=album_cover_url,
            rating=rating,
        )

        db.add(post)
        db.commit()
        db.refresh(post)

        return post