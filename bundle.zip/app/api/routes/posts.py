# app/api/routes/posts.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.schemas import WritePostRequest, WritePostResponse
from app.db.session import get_db
from app.di import get_post_service
from app.services.post_service import PostService

router = APIRouter()

@router.post("", response_model=WritePostResponse)
def create_post(
    req: WritePostRequest,
    db: Session = Depends(get_db),
    svc: PostService = Depends(get_post_service),
):
    try:
        # ✅ 카테고리 기본값 처리: 없으면 "default"
        category_name = (req.category or "default").strip()

        post = svc.create(
            db,
            title=req.title,
            description=req.description,
            body_mdx=req.body_mdx,
            posted_date=req.posted_date,
            status=req.status,
            category_name=category_name,  # ✅ 항상 최소 "default"
            album_ids=req.album_ids,      # ✅ 앨범 ID 리스트
            artist_ids = req.artist_ids,   # ✅ 아티스트 ID 리스트
            rating = req.rating
        )
        return WritePostResponse(id=str(post.id), slug=post.slug)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))