# app/api/schemas.py
from pydantic import BaseModel, Field
from typing import Optional, List, Literal, Dict
from datetime import date

# ====== Posts ======

class WritePostRequest(BaseModel):
    """
    프런트에서 오는 글쓰기 요청 스키마.
    - title, body_mdx, posted_date, status, category
    - album_ids: 선택된 앨범 id 리스트 (없으면 빈 리스트)
    - 음악 리뷰 관련 필드는 일단 옵션으로 둔 상태
    """
    model_config = {
        "populate_by_name": True,  # 필드 이름으로도 매핑 허용
        "extra": "ignore",         # 추가 필드는 무시
    }

    title: str = Field(min_length=1)
    body_mdx: str = Field(min_length=1)
    description: str = ""
    posted_date: date = Field(default_factory=date.today)
    status: Literal["draft", "published", "archived"] = "published"

    # 카테고리는 '이름'으로 받음 (서비스에서 id resolve)
    category: Optional[str] = None

    # 검색 인덱스 사용 여부 (프런트에서 안 보내면 기본 True)
    search_index: Optional[bool] = Field(default=True)

    # 선택된 앨범들 (write/index.ts에서 JSON 배열로 보내는 album_ids)
    album_ids: List[str] = Field(default_factory=list)
    artist_ids: list[str] = Field(default_factory=list)
    # --- Music Review (옵션, 나중에 쓸 여지) ---
    music_review_subject: Optional[Literal["album", "track"]] = Field(
        default=None, alias="musicReviewSubject"
    )
    review_target_id: Optional[str] = Field(default=None, alias="reviewTargetId")
    rating: Optional[float] = Field(default=None, ge=0, le=10)


class WritePostResponse(BaseModel):
    """
    /api/posts POST 응답용: 글 id + slug만 간단히 내려줌
    """
    id: str
    slug: str


# ====== Categories ======

class CategoryListResponse(BaseModel):
    categories: List[str]


class AddCategoryRequest(BaseModel):
    name: str = Field(min_length=1)


# ====== Metrics ======

class MetricsBatchRequest(BaseModel):
    slugs: List[str]


class PostMetrics(BaseModel):
    likes: int
    comments: int


class MetricsBatchResponse(BaseModel):
    data: Dict[str, PostMetrics]