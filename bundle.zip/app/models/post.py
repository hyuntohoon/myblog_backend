# app/models/post.py
import uuid
from datetime import date, datetime
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from sqlalchemy.types import Numeric

from sqlalchemy import (
    Text,
    Date,
    DateTime,
    BigInteger,
    Boolean,
    ForeignKey,
)
from sqlalchemy.dialects.postgresql import UUID as PGUUID, JSONB, ENUM as PGEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import text as sa_text

from app.db.base import Base
from app.models.album import post_albums
from app.models.artist import post_artists
from app.models.category import Category

# DB 스키마에 있는 ENUM post_status ('draft', 'published', 'archived')
POST_STATUS = PGEnum(
    "draft",
    "published",
    "archived",
    name="post_status",
    create_type=False,  # 이미 DB에 타입 있으므로 새로 만들지 않음
)


class Post(Base):
    __tablename__ = "posts"

    # id UUID PRIMARY KEY DEFAULT gen_random_uuid()
    id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        server_default=sa_text("gen_random_uuid()"),
    )

    # slug TEXT NOT NULL UNIQUE
    slug: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        unique=True,
        index=True,
    )

    # title TEXT NOT NULL
    title: Mapped[str] = mapped_column(Text, nullable=False)

    # description TEXT NOT NULL DEFAULT ''
    description: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        server_default="",
    )

    # body_mdx TEXT NOT NULL
    body_mdx: Mapped[str] = mapped_column(Text, nullable=False)

    # body_text TEXT
    body_text: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
    )

    # posted_date DATE NOT NULL
    posted_date: Mapped[date] = mapped_column(
        Date,
        nullable=False,
    )

    # last_updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    last_updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=sa_text("now()"),
    )

    # status post_status NOT NULL DEFAULT 'published'
    status: Mapped[str] = mapped_column(
        POST_STATUS,
        nullable=False,
        server_default="published",
    )

    # category_id BIGINT REFERENCES categories(id) ON DELETE SET NULL
    category_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        ForeignKey("categories.id", ondelete="SET NULL"),
        nullable=True,
    )

    category: Mapped[Optional["Category"]] = relationship(
        "Category",
        back_populates="posts",
        lazy="select",
    )

    # search_index BOOLEAN NOT NULL DEFAULT TRUE
    search_index: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default="true",
    )

    # extra JSONB NOT NULL DEFAULT '{}'::jsonb
    extra: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        server_default=sa_text("'{}'::jsonb"),
    )

    # 🔗 posts ↔ albums (post_albums)
    albums: Mapped[List["Album"]] = relationship(
        "Album",
        secondary=post_albums,
        back_populates="posts",
        lazy="select",
    )

    # 🔗 posts ↔ artists (post_artists)
    artists: Mapped[List["Artist"]] = relationship(
        "Artist",
        secondary=post_artists,
        back_populates="posts",
        lazy="select",
    )

    album_cover_url: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
    )

    rating: Mapped[float | None] = mapped_column(Numeric(3,1), nullable=True)

@dataclass
class PostDraft:
    title: str
    body_mdx: str
    description: str = ""
    posted_date: date = field(default_factory=date.today)
    status: str = "published"
    category_name: Optional[str] = None

    # 음악 리뷰 기능 (지금은 안 써도 되지만, 살려두고 싶으면 그대로)
    music_review_subject: Optional[str] = None
    review_target_id: Optional[str] = None
    rating: Optional[float] = None

    album_ids: List[str] = field(default_factory=list)
    artist_ids: List[str] = field(default_factory=list)

    album_cover_url: Optional[str] = None

    def validate(self):
        if not self.title:
            raise ValueError("title required")
        if not self.body_mdx:
            raise ValueError("body_mdx required")